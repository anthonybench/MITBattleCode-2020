package RedemptionPlayer;
import battlecode.common.*;

public class Building extends Robot {

    public Building(RobotController rc) {
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();
    }
}