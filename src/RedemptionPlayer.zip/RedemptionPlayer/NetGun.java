package RedemptionPlayer;

import battlecode.common.*;

public class NetGun extends Building {
    public NetGun(RobotController rc) {
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();
    }
}